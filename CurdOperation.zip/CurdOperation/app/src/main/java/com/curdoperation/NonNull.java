package com.curdoperation;

public @interface NonNull {
}
